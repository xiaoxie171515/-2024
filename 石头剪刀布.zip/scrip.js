javascript
// 定义难度级别

const DIFFICULTY_MEDIUM = 'medium';

// AI策略
const AI_STRATEGIES = {
    [DIFFICULTY_HARD]: () => Math.floor(Math.random() * 3), // 随机选择
    [DIFFICULTY_MEDIUM]: (playerChoice) => {
        // 假设AI可以观察玩家的上一轮选择并稍微调整其策略
        // 这里只是示例，实际上可能需要更复杂的逻辑
        let aiChoice;
        switch (playerChoice) {
            case 0: // 如果玩家选石头
                aiChoice = 2; // AI选剪子
                break;
            case 1: // 如果玩家选剪子
                aiChoice = 0; // AI选布
                break;
            case 2: // 如果玩家选布
                aiChoice = 1; // AI选石头
                break;
            default:
            //0=石头1=剪刀2=布
                aiChoice = Math.floor(Math.random() * 3); // 如果玩家选择未知，则AI随机选择
                break;
        }
        return aiChoice;
    },
    [DIFFICULTY_HARD]: () => {
        // 在困难模式下，AI可能使用更复杂的策略或机器学习模型
        // 这里只是一个示意性的函数，实际应用中需要实现具体的算法
        // 例如，使用机器学习模型来分析玩家的行为并预测最佳动作
        // ...
        //return Math.floor(Math.random() * 3); // 示例：仍然随机选择，但在实际应用中应替换为更智能的策略
    }
};

// 当前难度级别
let currentDifficulty = DIFFICULTY_MEDIUM;

// 获取AI选择
AI_STRATEGIES['MEDIUM']`：

const AI_STRATEGIES = {
    [DIFFICULTY_MEDIUM]: mediumStrategy,

};


// 示例：使用AI策略来选择一个动作
const playerChoice = 1; // 假设玩家选择了剪子
const aiChoice = getAIChoice(playerChoice); // AI根据玩家的选择和当前的难度级别做出选择
console.log(`玩家选择：${playerChoice}（剪子）`);
console.log(`AI选择：${aiChoice}`);

// 在这里，你可以进一步使用playerChoice和aiChoice来评估游戏的结果，例如：
// if (aiChoice === 2) {
//     console.log('AI赢了！');
// } else if (aiChoice === 0) {
//     console.log('打平了！');
// } else {
//     console.log('玩家赢了！');
// }
